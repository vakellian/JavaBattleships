public enum Piece {
    WATER, MISS, SHIP, DAMAGED_SHIP;
}
